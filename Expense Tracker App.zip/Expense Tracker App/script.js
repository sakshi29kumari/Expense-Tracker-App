let totalIncome = localStorage.getItem("totalIncome") || 0;
totalIncome = parseInt(totalIncome);

let remaining = localStorage.getItem("remainingBalance") || totalIncome;
remaining = parseInt(remaining);

document.getElementById("showIncome").innerText = totalIncome;
document.getElementById("balance").innerText = remaining;


let expenses = JSON.parse(localStorage.getItem("expenses")) || [];
let deletedHistory = JSON.parse(localStorage.getItem("deletedHistory")) || [];

const tableBody = document.getElementById("expenseTableBody");
const deletedTableBody = document.getElementById("deletedTableBody");

function renderExpenses() {
    tableBody.innerHTML = "";
    expenses.forEach((exp, index) => {
    let newRow = document.createElement("tr");
    newRow.innerHTML = `
        <td>${exp.type}</td>
        <td>${exp.category}</td>
        <td>${exp.date}</td>
        <td>${exp.description}</td>
        <td>₹${exp.amount}</td> <!-- CHANGE -->
        <td><button class="deleteBtn" data-index="${index}">Delete</button></td>
    `;
    tableBody.appendChild(newRow);
    });
}

function renderDeletedHistory() {
    deletedTableBody.innerHTML = "";
    deletedHistory.forEach(exp => {
    let newRow = document.createElement("tr");
    newRow.innerHTML = `
        <td>${exp.type}</td>
        <td>${exp.category}</td>
        <td>${exp.date}</td>
        <td>${exp.description}</td>
        <td>₹${exp.amount}</td>
    `;
    deletedTableBody.appendChild(newRow);
    });
}

renderExpenses();
renderDeletedHistory();

document.getElementById("expenseForm").addEventListener("submit", function(ele) {
    ele.preventDefault();

    let type = document.getElementById("type").value;
    let category = document.getElementById("category").value;
    let date = document.getElementById("date").value;
    let description = document.getElementById("description").value;
    let amount = parseInt(document.getElementById("total").value);

    if (!type || !category || !date || !amount) {
        alert("Please fill all required fields!");
        return;
    }

    let newExpense = { type, category, date, description, amount };
    expenses.push(newExpense);
    localStorage.setItem("expenses", JSON.stringify(expenses));

    remaining -= amount;
    document.getElementById("balance").innerText = remaining;
    localStorage.setItem("remainingBalance", remaining);

    renderExpenses();
    document.getElementById("expenseForm").reset();
});

tableBody.addEventListener("click", function(e) {
    if (e.target.classList.contains("deleteBtn")) {
        let index = e.target.getAttribute("data-index");
        let deletedExpense = expenses.splice(index, 1)[0];
        deletedHistory.push(deletedExpense);

        remaining += deletedExpense.amount;
        document.getElementById("balance").innerText = remaining;
        localStorage.setItem("remainingBalance", remaining);

        localStorage.setItem("expenses", JSON.stringify(expenses));
        localStorage.setItem("deletedHistory", JSON.stringify(deletedHistory));

        renderExpenses();
        renderDeletedHistory();
    }
});